import React, { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertTriangle, CircleCheck, CircleDashed, Clock, Gauge, LinkIcon, Lock, Play, RefreshCw, Search, WifiOff } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer, Legend } from "recharts";
import mqtt from "mqtt";

/**
 * Trunk‑Recorder MQTT Dashboard — wired for the "status" plugin schema you posted
 *
 * Supports messages:
 * - { type: "call_start", call: { ... } }
 * - { type: "calls_active", calls: [ ... ] }
 * - { type: "rates", rates: [ { sys_num, sys_name, decoderate, decoderate_interval, control_channel } ] }
 *
 * It still accepts other JSON messages under the base topic; those contribute to the observed msgs/min metric.
 */

const DEFAULTS = {
  url: "ws://10.1.0.28:1884",
  baseTopic: "trunk_recorder",
};

const fmtHz = (hz) => (hz ? `${(hz / 1e6).toFixed(6)} MHz` : "—");
const safeParse = (s) => { try { return JSON.parse(s); } catch { return null; } };
const fmtDuration = (sec) => {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h ? `${h}:${m.toString().padStart(2, "0")}:${r.toString().padStart(2, "0")}` : `${m}:${r.toString().padStart(2, "0")}`;
};
const systemLabel = (name, num) => name != null ? `${name}${Number.isFinite(num) ? ` [${num}]` : ""}` : (Number.isFinite(num) ? `sys ${num}` : "unknown");

export default function TrunkRecorderMQTTDashboard() {
  // Connection state
  const [url, setUrl] = useState(DEFAULTS.url);
  const [baseTopic, setBaseTopic] = useState(DEFAULTS.baseTopic);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [autoReconnect, setAutoReconnect] = useState(true);
  const [mockMode, setMockMode] = useState(false);
  const [connectRequested, setConnectRequested] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [status, setStatus] = useState("Disconnected");
  const clientRef = useRef(null);

  // Rates
  const [rateBuckets, setRateBuckets] = useState(() => new Map()); // systemKey -> [timestamps]
  const [pluginRates, setPluginRates] = useState(() => new Map()); // systemKey -> { decoderate, interval, control_channel, ts }

  // Calls
  const [activeCalls, setActiveCalls] = useState({}); // id -> callObj
  const [recentCalls, setRecentCalls] = useState([]);

  // Inspector
  const [lastMessages, setLastMessages] = useState([]);
  const lastMessagesRef = useRef([]);

  // Filter
  const [filter, setFilter] = useState("");

  // Connect / disconnect
  const connect = () => {
    setConnectRequested(true);
    if (mockMode) return;

    try {
      if (clientRef.current) {
        try { clientRef.current.end(true); } catch {}
        clientRef.current = null;
      }
      const opts = {
        clientId: `trdash_${Math.random().toString(16).slice(2)}`,
        clean: true,
        reconnectPeriod: autoReconnect ? 2000 : 0,
      };
      if (username) opts.username = username;
      if (password) opts.password = password;

      setStatus("Connecting…");
      const c = mqtt.connect(url, opts);
      clientRef.current = c;

      c.on("connect", () => {
        setIsConnected(true);
        setStatus("Connected");
        c.subscribe(`${baseTopic}/#`, { qos: 0 }, (err) => {
          if (err) setStatus(`Sub error: ${err.message}`);
        });
      });
      c.on("reconnect", () => setStatus("Reconnecting…"));
      c.on("close", () => { setIsConnected(false); setStatus("Disconnected"); });
      c.on("error", (err) => setStatus(`Error: ${err.message}`));
      c.on("message", (topic, buf) => {
        const text = buf.toString();
        const payload = safeParse(text) ?? { _raw: text };
        handleIncoming(topic, payload);
      });
    } catch (e) {
      setStatus(`Connect failed: ${e.message}`);
    }
  };

  const disconnect = () => {
    setConnectRequested(false);
    if (clientRef.current) {
      try { clientRef.current.end(true); } catch {}
      clientRef.current = null;
    }
    setIsConnected(false);
    setStatus("Disconnected");
  };

  // Ingest message
  const handleIncoming = (topic, payload) => {
    const now = Date.now();
    // Track observed rate under base topic (all JSON messages count)
    const sysGuess = (() => {
      // Use explicit sys_name/sys_num if present in top-level or nested call/rate objects; else infer from topic
      const c = payload.call || payload;
      const n = c?.sys_name ?? payload?.sys_name;
      const num = c?.sys_num ?? payload?.sys_num;
      const tParts = topic.split("/");
      const bParts = baseTopic ? baseTopic.split("/") : [];
      let i = 0; while (i < tParts.length && i < bParts.length && tParts[i] === bParts[i]) i++;
      const fromTopic = tParts[i];
      return { name: n, num, fromTopic };
    })();
    const sysKey = systemLabel(sysGuess.name ?? sysGuess.fromTopic, sysGuess.num);

    setRateBuckets((prev) => {
      const next = new Map(prev);
      const arr = next.get(sysKey) || [];
      arr.push(now);
      const cutoff = now - 60000;
      while (arr.length && arr[0] < cutoff) arr.shift();
      next.set(sysKey, arr);
      return next;
    });

    // Raw cache
    lastMessagesRef.current = [{ topic, payload, ts: now }, ...lastMessagesRef.current].slice(0, 200);
    setLastMessages(lastMessagesRef.current);

    // Typed handling
    const type = (payload?.type || "").toLowerCase();

    if (type === "rates" && Array.isArray(payload.rates)) {
      setPluginRates((prev) => {
        const next = new Map(prev);
        for (const r of payload.rates) {
          const key = systemLabel(r.sys_name, r.sys_num);
          next.set(key, {
            decoderate: Number(r.decoderate) || 0,
            interval: Number(r.decoderate_interval) || 1,
            control_channel: r.control_channel,
            ts: now,
          });
        }
        return next;
      });
      return;
    }

    if (type === "call_start" && payload.call) {
      upsertCall(payload.call, now);
      return;
    }

    if (type === "calls_active" && Array.isArray(payload.calls)) {
      for (const c of payload.calls) upsertCall(c, now);
      return;
    }

    // Generic messages: if they look like a call object without wrapper
    if (payload && (payload.talkgroup != null || payload.talkgroup_alpha_tag != null)) {
      upsertCall(payload, now);
    }
  };

  // Normalize and store a call object
  const upsertCall = (c, nowMs) => {
    const id = String(c.id ?? `${c.sys_name ?? "sys"}-${c.talkgroup ?? "tg"}-${c.freq ?? "freq"}-${c.unit ?? "src"}`);
    const startFromEpoch = Number.isFinite(c.start_time) ? c.start_time * 1000 : undefined;
    const durationFromElapsed = Number.isFinite(c.elapsed) ? c.elapsed : undefined; // seconds
    const startTs = startFromEpoch ?? (durationFromElapsed != null ? (nowMs - durationFromElapsed * 1000) : nowMs);
    const system = systemLabel(c.sys_name, c.sys_num);

    setActiveCalls((prev) => ({
      ...prev,
      [id]: {
        id,
        system,
        talkgroup: c.talkgroup,
        tgName: c.talkgroup_alpha_tag || "",
        tgDesc: c.talkgroup_description || "",
        tgGroup: c.talkgroup_group || "",
        tgTag: c.talkgroup_tag || "",
        frequency: c.freq,
        unit: c.unit,
        audio: c.audio_type,
        tdma: !!c.phase2_tdma,
        slot: c.tdma_slot,
        analog: !!c.analog,
        encrypted: !!c.encrypted,
        emergency: !!c.emergency,
        callState: c.call_state_type || "",
        monState: c.mon_state_type || "",
        meta: c,
        startTs: prev[id]?.startTs ?? startTs,
        lastUpdateTs: nowMs,
      }
    }));
  };

  // Housekeeping: close stale calls and trim buckets
  useEffect(() => {
    const iv = setInterval(() => {
      const now = Date.now();
      // Stale cutoff: no updates > 20s
      setActiveCalls((prev) => {
        const next = { ...prev };
        for (const [id, c] of Object.entries(prev)) {
          if (now - (c.lastUpdateTs || c.startTs) > 20000) {
            delete next[id];
            setRecentCalls((rc) => [{
              id,
              system: c.system,
              talkgroup: c.talkgroup,
              tgName: c.tgName,
              frequency: c.frequency,
              durationSec: Math.max(0, Math.round((now - c.startTs) / 1000)),
              endTs: now,
            }, ...rc].slice(0, 150));
          }
        }
        return next;
      });

      // Rate windows
      setRateBuckets((prev) => {
        const next = new Map();
        const cutoff = now - 60000;
        for (const [k, arr] of prev.entries()) {
          next.set(k, arr.filter((t) => t >= cutoff));
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  // Mock data for demo
  useEffect(() => {
    let t1, t2, t3;
    if (mockMode && connectRequested) {
      setStatus("Mocking data…");
      const systems = [
        { sys_name: "txwarn", sys_num: 0, cc: 774456250 },
        { sys_name: "txwarn", sys_num: 1, cc: 853950000 },
        { sys_name: "txwarn", sys_num: 2, cc: 773968750 },
      ];
      let callId = 0;

      // rates
      t1 = setInterval(() => {
        const rates = systems.map((s) => ({
          ...s,
          decoderate: Math.max(5, Math.round(Math.random() * 40)),
          decoderate_interval: 3,
          control_channel: s.cc,
        }));
        handleIncoming(`${baseTopic}/rates`, { type: "rates", rates });
      }, 3000);

      // active snapshot
      t2 = setInterval(() => {
        const calls = Array.from({ length: Math.floor(Math.random() * 3) + 2 }).map(() => {
          const s = systems[Math.floor(Math.random() * systems.length)];
          const tg = [1004, 2208, 2210, 2211, 30020, 40105][Math.floor(Math.random() * 6)];
          const freq = [852575000, 853762500, 771331250, 772268750][Math.floor(Math.random() * 4)];
          return {
            id: `mock_${callId++}`,
            sys_name: s.sys_name,
            sys_num: s.sys_num,
            talkgroup: tg,
            talkgroup_alpha_tag: tg === 30020 ? "HPD SE Disp" : "",
            talkgroup_description: tg === 2210 ? "GCI 1" : "",
            freq,
            start_time: Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 120),
            call_state_type: Math.random() < 0.7 ? "RECORDING" : "MONITORING",
            mon_state_type: Math.random() < 0.1 ? "ENCRYPTED" : "UNSPECIFIED",
            phase2_tdma: Math.random() < 0.5,
            tdma_slot: Math.random() < 0.5 ? 0 : 1,
            encrypted: Math.random() < 0.1,
            analog: Math.random() < 0.3,
          };
        });
        handleIncoming(`${baseTopic}/calls_active`, { type: "calls_active", calls });
      }, 2000);

      // occasional call_start
      t3 = setInterval(() => {
        const s = systems[Math.floor(Math.random() * systems.length)];
        const payload = { type: "call_start", call: {
          id: `mock_start_${callId++}`,
          sys_name: s.sys_name, sys_num: s.sys_num,
          talkgroup: 30020, talkgroup_alpha_tag: "HPD SE Disp",
          freq: 771331250,
          start_time: Math.floor(Date.now()/1000),
          call_state_type: "RECORDING",
          phase2_tdma: true, tdma_slot: 0,
        }};
        handleIncoming(`${baseTopic}/call_start`, payload);
      }, 5000);
    }
    return () => { clearInterval(t1); clearInterval(t2); clearInterval(t3); };
  }, [mockMode, connectRequested, baseTopic]);

  // Build chart rows with both observed msgs/min and plugin decoderate/min
  const rateSeries = useMemo(() => {
    const now = Date.now();
    const rows = [];
    const keys = new Set([...rateBuckets.keys(), ...pluginRates.keys()]);
    for (const k of keys) {
      const obsArr = rateBuckets.get(k) || [];
      const obsPerMin = obsArr.length / Math.max(1, (now - (obsArr[0] ?? now)) / 60000);
      const pr = pluginRates.get(k);
      const pluginPerMin = pr ? pr.decoderate * 60 : 0;
      rows.push({ system: k, observed: Math.round(obsPerMin), pluginRate: Math.round(pluginPerMin) });
    }
    rows.sort((a, b) => (b.pluginRate || b.observed) - (a.pluginRate || a.observed));
    return rows;
  }, [rateBuckets, pluginRates]);

  const systemStats = useMemo(() => {
    const list = [];
    for (const [k, pr] of pluginRates.entries()) {
      list.push({ system: k, control: pr.control_channel, decoderate: pr.decoderate, ts: pr.ts });
    }
    // Also include systems seen but not in pluginRates
    for (const k of rateBuckets.keys()) if (!pluginRates.has(k)) list.push({ system: k, control: null, decoderate: 0, ts: null });
    list.sort((a, b) => (b.decoderate || 0) - (a.decoderate || 0));
    return list;
  }, [pluginRates, rateBuckets]);

  const activeCallRows = useMemo(() => {
    const now = Date.now();
    const rows = Object.values(activeCalls).map((c) => ({
      ...c,
      duration: Math.round((now - c.startTs) / 1000),
    }));
    const f = filter.trim().toLowerCase();
    return f
      ? rows.filter((r) =>
          String(r.talkgroup ?? "").toLowerCase().includes(f) ||
          String(r.tgName ?? "").toLowerCase().includes(f) ||
          String(r.system ?? "").toLowerCase().includes(f) ||
          String(r.frequency ?? "").toLowerCase().includes(f)
        )
      : rows;
  }, [activeCalls, filter]);

  return (
    <div className="min-h-screen w-full bg-slate-50 p-4 md:p-6">
      <div className="mx-auto max-w-7xl space-y-4">
        <header className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Trunk‑Recorder MQTT Dashboard</h1>
            <p className="text-sm text-slate-600">Live message rates, control channels, and active calls (with talkgroup, status, slot, encryption, and duration).</p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 ${isConnected ? "bg-green-50 text-green-700" : mockMode ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-700"}`}>
              {isConnected ? <CircleCheck className="h-4 w-4"/> : mockMode ? <CircleDashed className="h-4 w-4"/> : <WifiOff className="h-4 w-4"/>}
              {status}
            </span>
          </div>
        </header>

        {/* Connection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><LinkIcon className="h-5 w-5"/>Connection</CardTitle>
            <CardDescription>WebSocket MQTT broker and base topic (subscribes to <code>{baseTopic}/#</code>).</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-12">
            <div className="md:col-span-5 space-y-2">
              <Label>Broker WebSocket URL</Label>
              <Input value={url} onChange={(e)=>setUrl(e.target.value)} placeholder="ws://broker:9001 or wss://broker/mqtt"/>
            </div>
            <div className="md:col-span-3 space-y-2">
              <Label>Base Topic</Label>
              <Input value={baseTopic} onChange={(e)=>setBaseTopic(e.target.value)} placeholder="trunk-recorder"/>
            </div>
            <div className="md:col-span-2 space-y-2">
              <Label>Username (optional)</Label>
              <Input value={username} onChange={(e)=>setUsername(e.target.value)}/>
            </div>
            <div className="md:col-span-2 space-y-2">
              <Label>Password (optional)</Label>
              <Input type="password" value={password} onChange={(e)=>setPassword(e.target.value)}/>
            </div>
            <div className="md:col-span-12 flex flex-wrap items-center gap-4 pt-1">
              <div className="flex items-center gap-2">
                <Switch checked={autoReconnect} onCheckedChange={setAutoReconnect} id="reconn"/>
                <Label htmlFor="reconn">Auto‑reconnect</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={mockMode} onCheckedChange={setMockMode} id="mock"/>
                <Label htmlFor="mock">Mock data</Label>
              </div>
              <div className="ml-auto flex items-center gap-2">
                {!isConnected && !connectRequested ? (
                  <Button onClick={connect} className="gap-2"><Play className="h-4 w-4"/> Connect</Button>
                ) : (
                  <Button variant="secondary" onClick={disconnect} className="gap-2"><RefreshCw className="h-4 w-4 rotate-180"/> Disconnect</Button>
                )}
                <Button variant="outline" onClick={()=>window.location.reload()} className="gap-2"><RefreshCw className="h-4 w-4"/> Reload</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rates & Stats */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card className="md:col-span-3">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2"><Gauge className="h-5 w-5"/>Message Rate by System</CardTitle>
              <CardDescription>Observed msgs/min (all JSON under base topic) vs plugin decoderate/min.</CardDescription>
            </CardHeader>
            <CardContent className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={rateSeries} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="system"/>
                  <YAxis allowDecimals={false}/>
                  <RTooltip/>
                  <Legend/>
                  <Bar dataKey="observed" name="observed msgs/min" />
                  <Bar dataKey="pluginRate" name="decoderate/min" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle>System Stats</CardTitle>
              <CardDescription>Control channel & current decoderate.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-xl border bg-white overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/60">
                      <TableHead>System</TableHead>
                      <TableHead>Control</TableHead>
                      <TableHead className="text-right">Decoderate/s</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {systemStats.length === 0 ? (
                      <TableRow><TableCell colSpan={3} className="text-center text-slate-500 py-6">No data yet.</TableCell></TableRow>
                    ) : (
                      systemStats.map((s) => (
                        <TableRow key={s.system}>
                          <TableCell className="font-medium">{s.system}</TableCell>
                          <TableCell>{fmtHz(s.control)}</TableCell>
                          <TableCell className="text-right">{s.decoderate?.toFixed(2) ?? "0.00"}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active calls */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Active Calls</CardTitle>
                <CardDescription>Auto‑closes if no updates for 20s. "REC" indicates recording/voice; "MON" is monitoring.</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-500"/>
                  <Input className="pl-8 w-64" placeholder="Filter by TG/name/system/freq" value={filter} onChange={(e)=>setFilter(e.target.value)}/>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border bg-white overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/60">
                    <TableHead className="w-[18%]">System</TableHead>
                    <TableHead className="w-[12%]">TG</TableHead>
                    <TableHead className="w-[20%]">TG Name</TableHead>
                    <TableHead className="w-[12%]">Freq</TableHead>
                    <TableHead className="w-[10%]">Duration</TableHead>
                    <TableHead className="w-[16%]">Status</TableHead>
                    <TableHead>Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeCallRows.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center text-slate-500 py-8">No active calls.</TableCell></TableRow>
                  ) : (
                    activeCallRows.map((c) => (
                      <TableRow key={c.id}>
                        <TableCell className="font-medium">{c.system}</TableCell>
                        <TableCell>{c.talkgroup ?? "—"}</TableCell>
                        <TableCell>{c.tgName || c.tgDesc || ""}</TableCell>
                        <TableCell>{c.frequency ? (c.frequency/1e6).toFixed(6) : "—"}</TableCell>
                        <TableCell>{fmtDuration(c.duration)}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <span className={`px-2 py-0.5 rounded-full ${c.callState?.includes("REC") ? "bg-green-50 text-green-700" : "bg-slate-100 text-slate-700"}`}>{c.callState?.replaceAll("_"," ") || ""}</span>
                            {c.monState && <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">{c.monState.replaceAll("_"," ")}</span>}
                            {c.encrypted && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-50 text-rose-700"><Lock className="h-3 w-3"/> ENC</span>}
                            {c.analog ? <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-700">Analog</span> : <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">Digital{c.tdma ? ` TDMA (slot ${c.slot})` : ""}</span>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs text-slate-600 max-w-[70ch] truncate">
                            {c.tgGroup && <span className="mr-3"><span className="text-slate-500">group:</span> {c.tgGroup}</span>}
                            {c.tgTag && <span className="mr-3"><span className="text-slate-500">tag:</span> {c.tgTag}</span>}
                            {c.unit != null && <span className="mr-3"><span className="text-slate-500">unit:</span> {c.unit}</span>}
                            {c.slot != null && c.tdma && <span className="mr-3"><span className="text-slate-500">slot:</span> {c.slot}</span>}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Recent calls & Inspector */}
        <Tabs defaultValue="recent">
          <TabsList>
            <TabsTrigger value="recent">Recent Ended Calls</TabsTrigger>
            <TabsTrigger value="inspector">Raw Message Inspector</TabsTrigger>
          </TabsList>
          <TabsContent value="recent">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Recent Ended Calls</CardTitle>
                <CardDescription>Auto‑pruned to the last 150.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-xl border bg-white overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50/60">
                        <TableHead>System</TableHead>
                        <TableHead>TG</TableHead>
                        <TableHead>TG Name</TableHead>
                        <TableHead>Freq</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Ended</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentCalls.length === 0 ? (
                        <TableRow><TableCell colSpan={6} className="text-center text-slate-500 py-8">No data yet.</TableCell></TableRow>
                      ) : (
                        recentCalls.map((c) => (
                          <TableRow key={c.id + c.endTs}>
                            <TableCell className="font-medium">{c.system}</TableCell>
                            <TableCell>{c.talkgroup ?? "—"}</TableCell>
                            <TableCell>{c.tgName || ""}</TableCell>
                            <TableCell>{c.frequency ? (c.frequency/1e6).toFixed(6) : "—"}</TableCell>
                            <TableCell>{fmtDuration(c.durationSec)}</TableCell>
                            <TableCell>{new Date(c.endTs).toLocaleTimeString()}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="inspector">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Raw Message Inspector</CardTitle>
                <CardDescription>Last 200 messages captured under <code>{baseTopic}/#</code>.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  {lastMessages.map((m, idx) => (
                    <div key={idx} className="rounded-lg border bg-white p-2 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-mono truncate">{m.topic}</div>
                        <div className="text-slate-500">{new Date(m.ts).toLocaleTimeString()}</div>
                      </div>
                      <pre className="mt-1 overflow-x-auto whitespace-pre-wrap">{JSON.stringify(m.payload, null, 2)}</pre>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card className="border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5"/>Notes</CardTitle>
            <CardDescription>Schema mapping for the provided plugin payloads.</CardDescription>
          </CardHeader>
          <CardContent className="text-sm space-y-2 text-slate-700">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>System key:</strong> uses <code>sys_name</code> and <code>sys_num</code> → label like <code>txwarn [2]</code>. Falls back to topic segment after Base Topic.</li>
              <li><strong>Rates:</strong> <code>decoderate</code> is treated as events/sec; the chart shows <em>decoderate/min</em> next to observed msgs/min.</li>
              <li><strong>Start time:</strong> prefers <code>start_time</code> (epoch seconds). If absent but <code>elapsed</code> exists, it back‑calculates.</li>
              <li><strong>Status badges:</strong> call state (e.g., <code>RECORDING</code>) and monitor state (e.g., <code>ENCRYPTED</code>) render as chips; encrypted also shows a lock.</li>
              <li><strong>Stale close:</strong> if a call isn’t refreshed for 20s it moves to “Recent Ended Calls” with its observed duration.</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
