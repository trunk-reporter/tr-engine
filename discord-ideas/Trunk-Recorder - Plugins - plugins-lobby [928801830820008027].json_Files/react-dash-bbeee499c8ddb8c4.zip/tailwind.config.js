export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"], // OK to keep for v3; v4 can omit
  theme: { extend: {} },
  plugins: [],
};
