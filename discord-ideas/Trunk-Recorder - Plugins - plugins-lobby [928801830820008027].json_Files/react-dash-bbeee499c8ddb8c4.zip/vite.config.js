import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";   // <-- use SWC here
import path from "node:path";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
});
